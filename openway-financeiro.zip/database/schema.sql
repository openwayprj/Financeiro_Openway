-- =====================================================================
--  OPENWAY FINANCEIRO - Schema do Banco de Dados (SQLite 3)
--  Compatível com PostgreSQL com ajustes mínimos:
--    INTEGER PRIMARY KEY AUTOINCREMENT  ->  SERIAL / BIGSERIAL
--    TEXT (datas ISO YYYY-MM-DD)        ->  DATE
--    valor_centavos INTEGER             ->  BIGINT (ou NUMERIC(14,2) em reais)
--
--  Convenções:
--    * Valores monetários armazenados em CENTAVOS (inteiro) -> sem erro de
--      arredondamento de ponto flutuante.
--    * Datas em ISO-8601 'YYYY-MM-DD' (ordenáveis como texto).
--    * Status do título NÃO é armazenado: é derivado (ver view v_titulos).
-- =====================================================================

PRAGMA foreign_keys = ON;

-- ---------------------------------------------------------------------
-- Segurança
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS usuarios (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  nome          TEXT    NOT NULL,
  login         TEXT    NOT NULL UNIQUE COLLATE NOCASE,
  senha_hash    TEXT    NOT NULL,
  perfil        TEXT    NOT NULL DEFAULT 'ADMIN' CHECK (perfil IN ('ADMIN','OPERADOR')),
  ativo         INTEGER NOT NULL DEFAULT 1 CHECK (ativo IN (0,1)),
  criado_em     TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS sessoes (
  token         TEXT    PRIMARY KEY,
  usuario_id    INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
  expira_em     TEXT    NOT NULL,
  criado_em     TEXT    NOT NULL DEFAULT (datetime('now'))
);

-- Configurações do sistema (chave/valor JSON) — ex.: alerta diário por e-mail
CREATE TABLE IF NOT EXISTS configuracoes (
  chave         TEXT    PRIMARY KEY,
  valor         TEXT    NOT NULL
);

-- ---------------------------------------------------------------------
-- Cadastros base
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS categorias (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  nome          TEXT    NOT NULL,
  tipo          TEXT    NOT NULL CHECK (tipo IN ('RECEITA','DESPESA')),
  natureza      TEXT    NOT NULL CHECK (natureza IN ('PESSOAL','EMPRESA','AMBOS')),  -- AMBOS = serve p/ Empresa e Pessoal
  ativo         INTEGER NOT NULL DEFAULT 1 CHECK (ativo IN (0,1)),
  UNIQUE (nome, tipo, natureza)
);

CREATE TABLE IF NOT EXISTS clientes (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  nome          TEXT    NOT NULL,           -- Nome / Razão Social
  cpf_cnpj      TEXT,                        -- somente dígitos
  contato       TEXT,                        -- pessoa de contato
  email         TEXT,
  telefone      TEXT,
  ativo         INTEGER NOT NULL DEFAULT 1 CHECK (ativo IN (0,1))
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_clientes_doc ON clientes(cpf_cnpj) WHERE cpf_cnpj IS NOT NULL AND cpf_cnpj <> '';

CREATE TABLE IF NOT EXISTS fornecedores (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  nome          TEXT    NOT NULL,
  cpf_cnpj      TEXT,
  contato       TEXT,
  email         TEXT,
  telefone      TEXT,
  ativo         INTEGER NOT NULL DEFAULT 1 CHECK (ativo IN (0,1))
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_fornecedores_doc ON fornecedores(cpf_cnpj) WHERE cpf_cnpj IS NOT NULL AND cpf_cnpj <> '';

CREATE TABLE IF NOT EXISTS colaboradores (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  nome          TEXT    NOT NULL,
  cargo         TEXT,
  status        TEXT    NOT NULL DEFAULT 'ATIVO' CHECK (status IN ('ATIVO','INATIVO'))
);

-- Expansão sugerida: onde o dinheiro entrou/saiu
CREATE TABLE IF NOT EXISTS formas_pagamento (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  nome          TEXT    NOT NULL UNIQUE,     -- Pix, Boleto, Cartão de Crédito...
  ativo         INTEGER NOT NULL DEFAULT 1 CHECK (ativo IN (0,1))
);

CREATE TABLE IF NOT EXISTS contas_bancarias (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  nome          TEXT    NOT NULL,            -- Ex.: Itaú PJ, Bradesco PF
  banco         TEXT,
  agencia       TEXT,
  conta         TEXT,
  natureza      TEXT    NOT NULL DEFAULT 'EMPRESA' CHECK (natureza IN ('PESSOAL','EMPRESA')),
  ativo         INTEGER NOT NULL DEFAULT 1 CHECK (ativo IN (0,1))
);

-- Centro de Custo (classificação gerencial das despesas: departamento, projeto, filial...)
CREATE TABLE IF NOT EXISTS centros_custo (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  codigo        TEXT,                        -- opcional, ex.: 1.01
  nome          TEXT    NOT NULL,
  descricao     TEXT,
  ativo         INTEGER NOT NULL DEFAULT 1 CHECK (ativo IN (0,1))
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_centros_custo_nome ON centros_custo(nome COLLATE NOCASE);
CREATE UNIQUE INDEX IF NOT EXISTS ux_centros_custo_cod ON centros_custo(codigo) WHERE codigo IS NOT NULL AND codigo <> '';

-- ---------------------------------------------------------------------
-- Lançamentos
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS contas_receber (
  nro_documento      INTEGER PRIMARY KEY AUTOINCREMENT,   -- sequencial
  data_emissao       TEXT    NOT NULL,
  data_vencimento    TEXT    NOT NULL,
  data_pagamento     TEXT,                                -- preenchida = recebido
  tipo_ambiente      TEXT    NOT NULL CHECK (tipo_ambiente IN ('PESSOAL','EMPRESA')),
  cliente_id         INTEGER NOT NULL REFERENCES clientes(id),
  categoria_id       INTEGER NOT NULL REFERENCES categorias(id),
  colaborador_id     INTEGER NOT NULL REFERENCES colaboradores(id),  -- responsável (obrigatório)
  valor_centavos     INTEGER NOT NULL CHECK (valor_centavos > 0),
  observacoes        TEXT,
  forma_pagamento_id INTEGER REFERENCES formas_pagamento(id),
  conta_bancaria_id  INTEGER REFERENCES contas_bancarias(id),
  criado_por         INTEGER REFERENCES usuarios(id),
  projetado_de       INTEGER,                             -- nº do título de origem quando gerado pela Projeção de Mês
  criado_em          TEXT    NOT NULL DEFAULT (datetime('now')),
  atualizado_em      TEXT    NOT NULL DEFAULT (datetime('now')),
  CHECK (data_vencimento >= data_emissao)
);
CREATE INDEX IF NOT EXISTS ix_cr_venc  ON contas_receber(data_vencimento);
CREATE INDEX IF NOT EXISTS ix_cr_pag   ON contas_receber(data_pagamento);
CREATE INDEX IF NOT EXISTS ix_cr_amb   ON contas_receber(tipo_ambiente);
CREATE INDEX IF NOT EXISTS ix_cr_colab ON contas_receber(colaborador_id);
CREATE INDEX IF NOT EXISTS ix_cr_proj  ON contas_receber(projetado_de);

CREATE TABLE IF NOT EXISTS contas_pagar (
  nro_documento      INTEGER PRIMARY KEY AUTOINCREMENT,
  data_emissao       TEXT    NOT NULL,
  data_vencimento    TEXT    NOT NULL,
  data_pagamento     TEXT,                                -- preenchida = liquidado
  tipo_ambiente      TEXT    NOT NULL CHECK (tipo_ambiente IN ('PESSOAL','EMPRESA')),
  fornecedor_id      INTEGER NOT NULL REFERENCES fornecedores(id),
  categoria_id       INTEGER NOT NULL REFERENCES categorias(id),
  colaborador_id     INTEGER REFERENCES colaboradores(id),   -- opcional
  centro_custo_id    INTEGER REFERENCES centros_custo(id),   -- opcional
  valor_centavos     INTEGER NOT NULL CHECK (valor_centavos > 0),
  observacoes        TEXT,
  forma_pagamento_id INTEGER REFERENCES formas_pagamento(id),
  conta_bancaria_id  INTEGER REFERENCES contas_bancarias(id),
  criado_por         INTEGER REFERENCES usuarios(id),
  projetado_de       INTEGER,                             -- nº do título de origem quando gerado pela Projeção de Mês
  criado_em          TEXT    NOT NULL DEFAULT (datetime('now')),
  atualizado_em      TEXT    NOT NULL DEFAULT (datetime('now')),
  CHECK (data_vencimento >= data_emissao)
);
CREATE INDEX IF NOT EXISTS ix_cp_venc  ON contas_pagar(data_vencimento);
CREATE INDEX IF NOT EXISTS ix_cp_pag   ON contas_pagar(data_pagamento);
CREATE INDEX IF NOT EXISTS ix_cp_amb   ON contas_pagar(tipo_ambiente);
CREATE INDEX IF NOT EXISTS ix_cp_colab ON contas_pagar(colaborador_id);
CREATE INDEX IF NOT EXISTS ix_cp_cc    ON contas_pagar(centro_custo_id);
CREATE INDEX IF NOT EXISTS ix_cp_proj  ON contas_pagar(projetado_de);

-- ---------------------------------------------------------------------
-- Rateio / participação de colaboradores (opcional, N por lançamento)
--   Soma dos valores <= valor do título (validado na API).
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS contas_receber_colaboradores (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  nro_documento   INTEGER NOT NULL REFERENCES contas_receber(nro_documento) ON DELETE CASCADE,
  colaborador_id  INTEGER NOT NULL REFERENCES colaboradores(id),
  valor_centavos  INTEGER NOT NULL CHECK (valor_centavos > 0),
  UNIQUE (nro_documento, colaborador_id)
);

CREATE TABLE IF NOT EXISTS contas_pagar_colaboradores (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  nro_documento   INTEGER NOT NULL REFERENCES contas_pagar(nro_documento) ON DELETE CASCADE,
  colaborador_id  INTEGER NOT NULL REFERENCES colaboradores(id),
  valor_centavos  INTEGER NOT NULL CHECK (valor_centavos > 0),
  UNIQUE (nro_documento, colaborador_id)
);

-- ---------------------------------------------------------------------
-- VIEW unificada de títulos com STATUS derivado
--   status = 'REALIZADO' se data_pagamento preenchida
--          = 'ATRASADO'  se sem pagamento e vencimento < hoje
--          = 'PENDENTE'  caso contrário
-- ---------------------------------------------------------------------
DROP VIEW IF EXISTS v_titulos;
CREATE VIEW v_titulos AS
SELECT 'RECEBER' AS natureza_titulo, nro_documento, data_emissao, data_vencimento, data_pagamento,
       tipo_ambiente, categoria_id, colaborador_id, valor_centavos,
       CASE WHEN data_pagamento IS NOT NULL THEN 'REALIZADO'
            WHEN data_vencimento < date('now','localtime') THEN 'ATRASADO'
            ELSE 'PENDENTE' END AS status
  FROM contas_receber
UNION ALL
SELECT 'PAGAR', nro_documento, data_emissao, data_vencimento, data_pagamento,
       tipo_ambiente, categoria_id, colaborador_id, valor_centavos,
       CASE WHEN data_pagamento IS NOT NULL THEN 'REALIZADO'
            WHEN data_vencimento < date('now','localtime') THEN 'ATRASADO'
            ELSE 'PENDENTE' END
  FROM contas_pagar;

-- ---------------------------------------------------------------------
-- VIEW de atribuição por colaborador (base do ranking e do resumo)
--   Regra: 1) cada linha de rateio atribui seu valor ao colaborador informado;
--          2) o SALDO não rateado (valor do título - soma do rateio) é atribuído
--             ao colaborador_id do título (responsável). Sem rateio -> 100% dele.
--          Em Contas a Pagar, se colaborador_id for nulo, o saldo não rateado
--          fica sem atribuição (despesa geral, não vinculada a colaborador).
--   Assim, em Contas a Receber a soma por colaborador sempre fecha com o total.
-- ---------------------------------------------------------------------
DROP VIEW IF EXISTS v_atribuicao_colaborador;
CREATE VIEW v_atribuicao_colaborador AS
SELECT 'RECEBER' AS natureza_titulo, r.nro_documento, r.tipo_ambiente, r.data_vencimento, r.data_pagamento,
       x.colaborador_id, x.valor_centavos, 'RATEIO' AS origem
  FROM contas_receber r JOIN contas_receber_colaboradores x ON x.nro_documento = r.nro_documento
UNION ALL
SELECT * FROM (
  SELECT 'RECEBER', r.nro_documento, r.tipo_ambiente, r.data_vencimento, r.data_pagamento, r.colaborador_id,
         r.valor_centavos - COALESCE((SELECT SUM(x.valor_centavos) FROM contas_receber_colaboradores x WHERE x.nro_documento = r.nro_documento), 0) AS v,
         'RESPONSAVEL'
    FROM contas_receber r
) WHERE v > 0
UNION ALL
SELECT 'PAGAR', p.nro_documento, p.tipo_ambiente, p.data_vencimento, p.data_pagamento,
       x.colaborador_id, x.valor_centavos, 'RATEIO'
  FROM contas_pagar p JOIN contas_pagar_colaboradores x ON x.nro_documento = p.nro_documento
UNION ALL
SELECT * FROM (
  SELECT 'PAGAR', p.nro_documento, p.tipo_ambiente, p.data_vencimento, p.data_pagamento, p.colaborador_id,
         p.valor_centavos - COALESCE((SELECT SUM(x.valor_centavos) FROM contas_pagar_colaboradores x WHERE x.nro_documento = p.nro_documento), 0) AS v,
         'RESPONSAVEL'
    FROM contas_pagar p WHERE p.colaborador_id IS NOT NULL
) WHERE v > 0;

-- Controle da Importação Diária (evita importar a mesma linha da planilha duas vezes)
CREATE TABLE IF NOT EXISTS importacao_registros (
  chave          TEXT    PRIMARY KEY,         -- "id:<ID da planilha>" ou "h:<hash da linha>#<ocorrência>"
  tipo           TEXT    NOT NULL CHECK (tipo IN ('pagar','receber')),
  nro_documento  INTEGER NOT NULL,
  importado_em   TEXT    NOT NULL DEFAULT (datetime('now')),
  importado_por  INTEGER REFERENCES usuarios(id)
);
