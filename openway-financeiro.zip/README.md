# Openway Financeiro

Sistema de **Contas a Pagar e Contas a Receber** — gestão **Pessoal e Empresarial** no mesmo ambiente, com dashboard executivo, rateio por colaborador e login.

## Como executar (Windows)

1. Instale o **Node.js 24 LTS** (mínimo 22.13) em https://nodejs.org (se ainda não tiver).
2. Dê dois cliques em **`iniciar.bat`**.
   - Na primeira vez ele instala as dependências (precisa de internet, ~1 min).
   - O navegador abre em `http://localhost:3000`.
3. No primeiro acesso, crie o **usuário administrador** (nome, login e senha).

Quer ver o sistema com dados de exemplo? Com o sistema fechado, rode **`dados-demonstracao.bat`** (só funciona com o banco sem lançamentos) e depois `iniciar.bat`.

### Linha de comando (alternativa)

```bash
npm install
npm run seed      # opcional: dados de demonstração
npm start         # http://localhost:3000
npm test          # testes automatizados da API
```

### Configurações (variáveis de ambiente)

| Variável | Padrão | Uso |
|---|---|---|
| `PORT` | `3000` | Porta HTTP |
| `HOST` | `127.0.0.1` | Use `0.0.0.0` para permitir acesso de outros computadores da rede (edite `iniciar.bat`) |
| `DB_FILE` | `data/financeiro.db` | Caminho do banco |

## Backup

Todo o banco está em **`data/financeiro.db`**. Para backup, feche o sistema e copie esse arquivo (e, se existirem, `financeiro.db-wal` / `financeiro.db-shm`). Para restaurar, substitua o arquivo.

## Funcionalidades

- **Dashboard executivo**: filtros globais de período (Este Mês, Mês Anterior, Próximo Mês, Ano Atual ou intervalo livre) e âmbito (Todas / Apenas Pessoal / Apenas Empresa); KPIs de Total Previsto, Total Realizado, Resultado Previsto e Resultado Realizado; gráfico Receber x Pagar no tempo (previsto x realizado); rosca de status (Realizado / Pendente / Em Atraso); ranking de receitas por colaborador; despesas atreladas a colaboradores; top categorias; próximos vencimentos.
- **Calendário Financeiro**: visão estilo Outlook por **Dia / Semana / Mês** com os títulos a receber (verde) e a pagar (vermelho) em cada dia; totais por dia, por semana (coluna lateral no mês) e do período (a receber, a pagar, saldo, quitado x em aberto); quitados riscados, atrasados destacados; filtros Pessoal/Empresa, Receber/Pagar e mostrar quitados; clique no título para ver detalhes, baixar, estornar, editar ou excluir; "+" no dia cria lançamento já com o vencimento; atalhos ← → (navegar), T (hoje), D/S/M (visão).
- **Contas a Receber / Pagar**: número de documento sequencial automático, filtros (status, categoria, colaborador, data de referência), baixa e estorno, exportação CSV.
- **Projetar Mês**: copia os lançamentos de um mês (Receber, Pagar ou ambos; Pessoal, Empresa ou ambos) para outro mês, **sem data de pagamento**. Permite desmarcar itens e ajustar valores antes de gerar, avisa quando um título já foi projetado para o mês de destino e mantém rateio, centro de custo e demais dados. Acesso pelo menu ou pelo botão *Projetar mês* nas telas de Contas a Receber/Pagar.
- **Importação Diária (Google Sheets)**: botão **Gerar planilha modelo** (aba *Lançamentos* + abas com Fornecedores, Clientes, Categorias, Formas de Pagamento, Centros de Custo e Colaboradores, com listas de seleção e instruções). A planilha fica no Google Sheets compartilhada por link (leitor); todo dia você informa a data (emissão, vencimento, pagamento ou todas) e o sistema lê a planilha, mostra a prévia e lança Pagar e Receber de uma vez. Linhas já importadas são ignoradas (controle por ID ou impressão digital da linha), uma Data de Pagamento preenchida depois vira **baixa** do título, títulos iguais lançados à mão aparecem como *possível duplicado*, nomes parecidos são ajustados ao cadastro e cadastros novos são criados. Também aceita o arquivo .xlsx/.csv.
- **Importar Planilha — outros formatos (Contas a Pagar e a Receber)**: lê .xlsx/.csv (com escolha da aba) pelo cabeçalho (Fornecedor/Cliente — ou duas colunas Descrição —, Descrição, Tipo P/E, Vencimento, Valor, Categoria, Centro de Custo e opcionais); em Receber usa o colaborador responsável padrão informado; cria automaticamente fornecedores, categorias (natureza pelo tipo P/E) e centros de custo, unifica nomes parecidos, mostra prévia com pendências editáveis e grava tudo numa transação.
- **Alertas por E-mail (somente administradores)**: resumo diário (padrão 08:00) com as contas a pagar do dia, em atraso e dos próximos dias, e opcionalmente o que há para receber; na sexta inclui o fim de semana. Envio por SMTP próprio (Gmail com *senha de app*), prévia do e-mail, botão de envio imediato e agendamento automático no **Agendador de Tarefas do Windows** (pela tela ou por `agendar-alerta.bat`; remover com `remover-alerta.bat`). Funciona com o sistema fechado; se o PC estiver desligado no horário, envia assim que ligar (uma vez por dia). Log em `data/logs/alerta-email.log`.
- **Manutenção do Banco (somente administradores)**: zera os lançamentos (ou lançamentos e cadastros) com backup automático em `data/backups/` e reinicia a numeração.
- **Rateio por colaborador (opcional)**: em cada título, informe um ou mais colaboradores e o valor de cada um. O saldo não rateado fica com o colaborador responsável.
- **Centro de Custo (Contas a Pagar)**: campo opcional no lançamento, filtro na lista, card no dashboard e tela **Resumo por Centro de Custo** com evolução mensal empilhada, participação %, demonstrativo (previsto, realizado, % executado, em aberto, em atraso), categorias e fornecedores por centro, extrato de títulos e exportação CSV.
- **Resumo por Colaborador**: receita trazida x despesa gerada, saldo previsto e realizado, extrato de títulos por colaborador.
- **Cadastros**: Categorias/Plano de Contas, Clientes, Fornecedores, Colaboradores, Formas de Pagamento, Contas Bancárias e Usuários.
- **Regras**: status derivado da data de pagamento; categoria deve ser do mesmo ambiente do título (Princípio da Entidade); CPF/CNPJ validado; cadastros em uso não podem ser excluídos (inative-os).

## Documentação técnica

- [`docs/ARQUITETURA.md`](docs/ARQUITETURA.md) — modelo de dados, regras de negócio, regras de cálculo do dashboard, endpoints e layout.
- [`database/schema.sql`](database/schema.sql) — schema SQL (tabelas, índices e views).
- [`database/schema.prisma`](database/schema.prisma) — mesmas entidades em Prisma (para migração futura a PostgreSQL).
