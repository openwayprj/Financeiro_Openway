'use strict';
const path = require('path');
const express = require('express');
const cookieParser = require('cookie-parser');
const { DB_FILE } = require('./db');
const auth = require('./auth');
const cadastros = require('./routes/cadastros');
const lancamentos = require('./routes/lancamentos');
const dashboard = require('./routes/dashboard');
const centros = require('./routes/centros');
const projecao = require('./routes/projecao');
const importacao = require('./routes/importacao');
const importacaoDiaria = require('./routes/importacao-diaria');
const admin = require('./routes/admin');
const { HttpError } = require('./util');

const app = express();
app.disable('x-powered-by');
const jsonPadrao = express.json({ limit: '1mb' });
app.use((req, res, next) => (req.path.startsWith('/api/importacao') ? next() : jsonPadrao(req, res, next)));
app.use(cookieParser());

// Cabeçalhos básicos de segurança
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'same-origin');
  next();
});

// ---------------- API ----------------
app.use('/api/auth', auth.router);
app.use('/api', auth.exigirLogin);
app.use('/api/usuarios', auth.usuarios);
app.use('/api/cadastros', cadastros);
app.use('/api/receber', lancamentos.receber);
app.use('/api/pagar', lancamentos.pagar);
app.use('/api', dashboard);
app.use('/api', centros);
app.use('/api', projecao);
app.use('/api', importacao.router);
app.use('/api', importacaoDiaria.router);
app.use('/api/admin', admin);
app.use('/api', (req, res, next) => next(new HttpError(404, 'Rota não encontrada.')));

// ---------------- Front-end ----------------
app.use('/vendor/chart.js', express.static(path.join(__dirname, '..', 'node_modules', 'chart.js', 'dist')));
app.use(express.static(path.join(__dirname, '..', 'public')));
app.get(/^\/(?!api\/).*/, (req, res) => res.sendFile(path.join(__dirname, '..', 'public', 'index.html')));

// ---------------- Tratamento de erros ----------------
app.use((err, req, res, next) => { // eslint-disable-line no-unused-vars
  let status = err.status || 500;
  let msg = err.message || 'Erro interno.';
  const sqlMsg = String(err.errstr || '') + ' ' + String(err.message || '');
  if (err.errcode === 787 || err.code === 'SQLITE_CONSTRAINT_FOREIGNKEY' || /FOREIGN KEY constraint failed/.test(sqlMsg)) {
    status = 409; msg = 'Este registro está em uso por outros lançamentos e não pode ser excluído. Considere inativá-lo.';
  } else if (err.errcode === 2067 || err.errcode === 1555 || /UNIQUE constraint failed/.test(sqlMsg)) {
    status = 409; msg = 'Já existe um registro com esses dados (duplicidade).';
  } else if (err.type === 'entity.parse.failed') {
    status = 400; msg = 'JSON inválido.';
  } else if (status === 500) {
    console.error(err);
    msg = 'Erro interno no servidor.';
  }
  res.status(status).json({ erro: msg });
});

const PORT = Number(process.env.PORT) || 3000;
const HOST = process.env.HOST || '127.0.0.1';
if (require.main === module) {
  app.listen(PORT, HOST, () => {
    console.log('==============================================');
    console.log('  OPENWAY FINANCEIRO');
    console.log(`  Acesse: http://${HOST === '0.0.0.0' ? 'localhost' : HOST}:${PORT}`);
    console.log(`  Banco : ${DB_FILE}`);
    console.log('==============================================');
  });
}

module.exports = app;
