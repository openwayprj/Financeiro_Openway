'use strict';
/**
 * Manutenção do banco (somente ADMIN).
 *  - GET  /api/admin/estatisticas  -> quantidade de registros por tabela
 *  - POST /api/admin/zerar         -> { modo: 'lancamentos' | 'tudo', confirmacao: 'ZERAR' }
 *      lancamentos: apaga Contas a Receber/Pagar e rateios (mantém cadastros e usuários)
 *      tudo       : também apaga categorias, clientes, fornecedores, colaboradores, centros de custo e
 *                   contas bancárias (mantém usuários e formas de pagamento)
 *    Antes de apagar, grava um backup automático em data/backups/ (VACUUM INTO).
 *  - POST /api/admin/backup         -> cria data/backups/backup-AAAAMMDD-HHMMSS.db (com o sistema aberto)
 *  - GET  /api/admin/backups        -> lista os backups;  GET /api/admin/backups/:nome -> download
 */
const fs = require('fs');
const path = require('path');
const express = require('express');
const { db, DB_FILE } = require('../db');
const { HttpError } = require('../util');
const { exigirAdmin } = require('../auth');

const router = express.Router();
router.use(exigirAdmin);

const LANC = ['contas_receber_colaboradores', 'contas_pagar_colaboradores', 'contas_receber', 'contas_pagar'];
const CAD = ['categorias', 'clientes', 'fornecedores', 'colaboradores', 'centros_custo', 'contas_bancarias'];
const contar = () => Object.fromEntries([...LANC, ...CAD, 'formas_pagamento', 'usuarios']
  .map((t) => [t, db.prepare(`SELECT COUNT(*) AS n FROM ${t}`).get().n]));

const DIR_BACKUP = () => path.join(path.dirname(DB_FILE), 'backups');
function backup(prefixo = 'financeiro') {
  const dir = DIR_BACKUP();
  fs.mkdirSync(dir, { recursive: true });
  const d = new Date(), p = (n) => String(n).padStart(2, '0');
  const base = `${prefixo}-${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`;
  let arq = path.join(dir, `${base}.db`);
  for (let i = 2; fs.existsSync(arq); i++) arq = path.join(dir, `${base}-${i}.db`);
  db.exec(`VACUUM INTO '${arq.replace(/'/g, "''")}'`);
  return arq;
}

router.get('/estatisticas', (req, res) => res.json(contar()));

// ---------------- Backup ----------------
const NOME_OK = /^[\w.-]+\.db$/;
router.post('/backup', (req, res) => {
  const arq = backup('backup');
  res.status(201).json({ nome: path.basename(arq), bytes: fs.statSync(arq).size });
});
router.get('/backups', (req, res) => {
  const dir = DIR_BACKUP();
  const lista = fs.existsSync(dir) ? fs.readdirSync(dir).filter((n) => NOME_OK.test(n)).map((nome) => {
    const st = fs.statSync(path.join(dir, nome));
    return { nome, bytes: st.size, data: st.mtime.toISOString() };
  }).sort((a, b) => b.data.localeCompare(a.data)) : [];
  res.json({ pasta: dir, backups: lista });
});
router.get('/backups/:nome', (req, res) => {
  const nome = req.params.nome;
  const arq = path.join(DIR_BACKUP(), nome);
  if (!NOME_OK.test(nome) || !fs.existsSync(arq)) throw new HttpError(404, 'Backup não encontrado.');
  res.download(arq, nome);
});

router.post('/zerar', (req, res) => {
  const { modo, confirmacao } = req.body || {};
  if (!['lancamentos', 'tudo'].includes(modo)) throw new HttpError(400, 'Modo inválido.');
  if (confirmacao !== 'ZERAR') throw new HttpError(400, 'Digite ZERAR para confirmar.');
  const antes = contar();
  const arqBackup = backup();
  const tabelas = modo === 'tudo' ? [...LANC, ...CAD] : LANC;
  db.transaction(() => {
    for (const t of tabelas) db.exec(`DELETE FROM ${t}`);
    db.exec('DELETE FROM importacao_registros'); // a numeração recomeça: o controle de duplicidade da importação diária perde o sentido
    // Reinicia a numeração (Nº Documento volta a 1)
    db.exec(`DELETE FROM sqlite_sequence WHERE name IN (${tabelas.map((t) => `'${t}'`).join(',')})`);
  })();
  res.json({ ok: true, modo, backup: path.relative(path.join(__dirname, '..', '..'), arqBackup), apagados: Object.fromEntries(tabelas.map((t) => [t, antes[t]])) });
});

// ---------------- Alerta diário por e-mail ----------------
const alerta = require('../alerta');
const semSenha = (c) => ({ ...c, smtp: { ...c.smtp, senha: '', temSenha: !!c.smtp.senha } });

router.get('/alerta', (req, res) => res.json({ config: semSenha(alerta.lerConfig()), estado: alerta.estado() }));

router.put('/alerta', (req, res) => {
  const atual = alerta.lerConfig();
  const b = req.body || {};
  const s = b.smtp || {};
  const para = String(b.destinatarios || '').split(/[;,\s]+/).filter(Boolean);
  if (!para.length || para.some((e) => !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(e))) throw new HttpError(400, 'Informe e-mails de destino válidos (separados por vírgula).');
  if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(b.horario || '')) throw new HttpError(400, 'Horário inválido (use HH:MM).');
  const cfg = {
    ativo: !!b.ativo, destinatarios: para.join(', '), horario: b.horario,
    diasAFrente: Math.max(0, Math.min(30, Number(b.diasAFrente) || 0)),
    incluirAtrasados: !!b.incluirAtrasados, incluirReceber: !!b.incluirReceber,
    fimDeSemanaNaSexta: !!b.fimDeSemanaNaSexta, enviarSemVencimentos: !!b.enviarSemVencimentos,
    smtp: {
      host: String(s.host || '').trim(), porta: Number(s.porta) || 465,
      seguranca: ['ssl', 'starttls', 'nenhuma'].includes(s.seguranca) ? s.seguranca : 'ssl',
      usuario: String(s.usuario || '').trim(),
      senha: s.senha ? String(s.senha).replace(/\s+/g, '') : atual.smtp.senha, // vazio = mantém a atual
      remetente: String(s.remetente || '').trim(), remetenteNome: String(s.remetenteNome || 'Openway Financeiro').trim(),
      ignorarCertificado: !!s.ignorarCertificado,
    },
  };
  alerta.salvarConfig(cfg);
  res.json({ config: semSenha(cfg), estado: alerta.estado() });
});

router.get('/alerta/previa', (req, res) => {
  const r = alerta.montarResumo(alerta.lerConfig(), req.query.data);
  res.json({ assunto: r.assunto, html: r.html });
});

router.post('/alerta/enviar', async (req, res, next) => {
  try { res.json(await alerta.enviarResumo({ forcar: true })); } catch (e) { next(new HttpError(400, 'Falha no envio: ' + e.message)); }
});

// ---------------- Agendamento no Windows (Agendador de Tarefas) ----------------
const { execFile } = require('child_process');
const TAREFA = 'Openway Financeiro - Alerta diario';
const RAIZ = path.join(__dirname, '..', '..');
const ps = (args) => new Promise((ok) => execFile('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', ...args],
  { windowsHide: true, timeout: 30000 }, (err, stdout, stderr) => ok({ ok: !err, saida: String(stdout || '').trim(), erro: String(stderr || (err && err.message) || '').trim() })));

router.get('/alerta/agendamento', async (req, res) => {
  if (process.platform !== 'win32') return res.json({ suportado: false });
  const r = await ps(['-Command', `$t = Get-ScheduledTask -TaskName '${TAREFA}' -ErrorAction SilentlyContinue; if ($t) { $i = $t | Get-ScheduledTaskInfo; ` +
    `'{0}|{1}|{2}|{3}' -f $t.State, $i.NextRunTime.ToString('dd/MM/yyyy HH:mm'), $(if ($i.LastRunTime.Year -gt 2000) { $i.LastRunTime.ToString('dd/MM/yyyy HH:mm') } else { '' }), $i.LastTaskResult }`]);
  if (!r.saida) return res.json({ suportado: true, agendado: false });
  const [estadoT, proxima, ultima, resultado] = r.saida.split('|');
  res.json({ suportado: true, agendado: true, estado: estadoT, proxima, ultima, resultado });
});

router.post('/alerta/agendamento', async (req, res) => {
  if (process.platform !== 'win32') throw new HttpError(400, 'O agendamento automático só funciona com o sistema rodando no Windows.');
  const hora = alerta.lerConfig().horario;
  const r = await ps(['-File', path.join(RAIZ, 'agendar-alerta.ps1'), '-Hora', hora]);
  if (!r.ok) throw new HttpError(400, 'Não foi possível agendar: ' + (r.erro || r.saida) + ' — tente executar agendar-alerta.bat como Administrador.');
  res.json({ ok: true, mensagem: r.saida });
});

router.delete('/alerta/agendamento', async (req, res) => {
  if (process.platform !== 'win32') throw new HttpError(400, 'Disponível apenas no Windows.');
  await ps(['-Command', `Unregister-ScheduledTask -TaskName '${TAREFA}' -Confirm:$false -ErrorAction SilentlyContinue`]);
  res.json({ ok: true });
});

module.exports = router;
