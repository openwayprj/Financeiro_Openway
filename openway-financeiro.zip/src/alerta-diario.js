'use strict';
/**
 * Envio do resumo diário por e-mail (executado pelo Agendador de Tarefas do Windows via enviar-alerta.bat).
 * Uso: node src/alerta-diario.js [--forcar]
 *  - Sem --forcar: não envia de novo se o resumo do dia já foi enviado (evita duplicidade quando o
 *    computador liga depois do horário e a tarefa roda "assim que possível").
 */
const { enviarResumo } = require('./alerta');

const agora = () => new Date().toLocaleString('pt-BR');
enviarResumo({ forcar: process.argv.includes('--forcar') })
  .then((r) => {
    console.log(`[${agora()}] ${r.enviado ? `Enviado para ${r.para.join(', ')} — ${r.assunto}` : `Não enviado: ${r.motivo}`}`);
    process.exit(0);
  })
  .catch((e) => {
    console.error(`[${agora()}] ERRO: ${e.message}`);
    process.exit(1);
  });
