'use strict';
/**
 * Acesso ao banco SQLite usando o módulo NATIVO do Node.js (node:sqlite).
 * Não depende de compilação C++ (Visual Studio) nem de pacotes nativos.
 * Requer Node.js 22.13+ (recomendado: Node 24 LTS).
 *
 * Expõe uma API mínima compatível com a usada no sistema:
 *   db.prepare(sql).get/all/run(params)   db.exec(sql)   db.transaction(fn)
 */
const fs = require('fs');
const path = require('path');

let DatabaseSync;
try {
  ({ DatabaseSync } = require('node:sqlite'));
} catch (e) {
  console.error('\n[ERRO] Esta versão do Node.js não possui SQLite embutido.');
  console.error(`       Versão atual: ${process.version}. Instale o Node.js 24 LTS em https://nodejs.org\n`);
  process.exit(1);
}

const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, '..', 'data');
const DB_FILE = process.env.DB_FILE || path.join(DATA_DIR, 'financeiro.db');

fs.mkdirSync(path.dirname(DB_FILE), { recursive: true });

const raw = new DatabaseSync(DB_FILE);
raw.exec('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 5000;');

/** Converte parâmetros: objeto nomeado -> apenas as chaves usadas no SQL; undefined -> null */
function prepare(sql) {
  const st = raw.prepare(sql);
  const nomes = [...new Set([...sql.matchAll(/[@$:]([A-Za-z_]\w*)/g)].map((m) => m[1]))];
  const params = (args) => {
    if (args.length === 1 && args[0] !== null && typeof args[0] === 'object' && !Array.isArray(args[0])) {
      const o = {};
      for (const k of nomes) o[k] = args[0][k] === undefined ? null : args[0][k];
      return [o];
    }
    return args.map((v) => (v === undefined ? null : v));
  };
  return {
    get: (...a) => st.get(...params(a)),
    all: (...a) => st.all(...params(a)),
    run: (...a) => {
      const r = st.run(...params(a));
      return { changes: Number(r.changes), lastInsertRowid: Number(r.lastInsertRowid) };
    },
  };
}

/** Envolve fn em BEGIN/COMMIT, com ROLLBACK em caso de erro */
function transaction(fn) {
  return (...args) => {
    raw.exec('BEGIN');
    try {
      const r = fn(...args);
      raw.exec('COMMIT');
      return r;
    } catch (e) {
      raw.exec('ROLLBACK');
      throw e;
    }
  };
}

const db = { prepare, transaction, exec: (sql) => raw.exec(sql) };

// ---- Migração: categorias.natureza passa a aceitar 'AMBOS' (bancos criados na v1) ----
const catSql = raw.prepare("SELECT sql FROM sqlite_master WHERE type = 'table' AND name = 'categorias'").get();
if (catSql && !catSql.sql.includes('AMBOS')) {
  raw.exec(`PRAGMA foreign_keys = OFF;
    BEGIN;
    CREATE TABLE categorias_nova (
      id       INTEGER PRIMARY KEY AUTOINCREMENT,
      nome     TEXT    NOT NULL,
      tipo     TEXT    NOT NULL CHECK (tipo IN ('RECEITA','DESPESA')),
      natureza TEXT    NOT NULL CHECK (natureza IN ('PESSOAL','EMPRESA','AMBOS')),
      ativo    INTEGER NOT NULL DEFAULT 1 CHECK (ativo IN (0,1)),
      UNIQUE (nome, tipo, natureza)
    );
    INSERT INTO categorias_nova (id, nome, tipo, natureza, ativo) SELECT id, nome, tipo, natureza, ativo FROM categorias;
    DROP TABLE categorias;
    ALTER TABLE categorias_nova RENAME TO categorias;
    COMMIT;
    PRAGMA foreign_keys = ON;`);
  console.log('[migração] Categorias: natureza "Empresa e Pessoal" habilitada.');
}

// ---- Migração: Centro de Custo em Contas a Pagar ----
const temPagar = raw.prepare("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = 'contas_pagar'").get();
if (temPagar && !raw.prepare('PRAGMA table_info(contas_pagar)').all().some((c) => c.name === 'centro_custo_id')) {
  raw.exec('ALTER TABLE contas_pagar ADD COLUMN centro_custo_id INTEGER REFERENCES centros_custo(id)');
  console.log('[migração] Contas a Pagar: campo Centro de Custo adicionado.');
}

// ---- Migração: rastreio da Projeção de Mês (título de origem) ----
for (const t of ['contas_receber', 'contas_pagar']) {
  const existe = raw.prepare("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = ?").get(t);
  if (existe && !raw.prepare(`PRAGMA table_info(${t})`).all().some((c) => c.name === 'projetado_de')) {
    raw.exec(`ALTER TABLE ${t} ADD COLUMN projetado_de INTEGER`);
    console.log(`[migração] ${t}: campo projetado_de adicionado.`);
  }
}

// Aplica o schema (idempotente: CREATE ... IF NOT EXISTS / DROP VIEW + CREATE VIEW)
db.exec(fs.readFileSync(path.join(__dirname, '..', 'database', 'schema.sql'), 'utf8'));

// Dados auxiliares padrão na primeira execução
if (db.prepare('SELECT COUNT(*) AS n FROM formas_pagamento').get().n === 0) {
  const ins = db.prepare('INSERT INTO formas_pagamento (nome) VALUES (?)');
  ['Pix', 'Boleto', 'Transferência (TED/DOC)', 'Cartão de Crédito', 'Cartão de Débito', 'Dinheiro', 'Débito Automático']
    .forEach((n) => ins.run(n));
}

module.exports = { db, DB_FILE };
